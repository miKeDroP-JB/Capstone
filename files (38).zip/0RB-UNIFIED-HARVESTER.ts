/**
 * ═══════════════════════════════════════════════════════════════
 * 0RB UNIFIED HARVESTER
 * "The Pattern Reader That Builds The Builder"
 * ═══════════════════════════════════════════════════════════════
 * 
 * This system reads ALL your code, extracts patterns, compresses them,
 * and stores them in the grimoire for instant manifestation.
 * 
 * FLOW:
 *   BUILDS → HARVESTER → PATTERN READER → GLYPH COMPRESSION → GRIMOIRE → BUILDER
 * 
 * Once this runs, ANY prompt can manifest ANY app because the patterns
 * are already stored as compressed intelligence.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

interface HarvestedPattern {
  id: string;
  type: 'class' | 'function' | 'interface' | 'component' | 'hook' | 'config' | 'prompt' | 'blueprint';
  name: string;
  domain: string;
  source: string;
  code: string;
  compressed: string;
  tokens: number;
  compressedTokens: number;
  compressionRatio: number;
  triggers: string[];
  dependencies: string[];
  capabilities: string[];
  metadata: {
    filePath: string;
    lineStart: number;
    lineEnd: number;
    harvestedAt: Date;
    version: string;
  };
}

interface GrimoireEntry {
  glyph: string;
  patterns: HarvestedPattern[];
  accessCount: number;
  lastAccessed: Date;
  successRate: number;
  manifestations: number;
}

interface HarvesterStats {
  filesProcessed: number;
  patternsExtracted: number;
  totalLines: number;
  totalTokens: number;
  compressedTokens: number;
  avgCompressionRatio: number;
  domains: Record<string, number>;
  types: Record<string, number>;
}

// ═══════════════════════════════════════════════════════════════
// GLYPH COMPRESSION ENGINE
// ═══════════════════════════════════════════════════════════════

class GlyphEngine {
  private glyphMap: Map<string, string> = new Map();
  private reverseMap: Map<string, string> = new Map();
  private counter = 0;

  // Common patterns that get compressed to single glyphs
  private readonly COMMON_PATTERNS: Record<string, string> = {
    'export default function': '⊕ƒ',
    'export const': '⊕©',
    'export interface': '⊕⌐',
    'export class': '⊕℃',
    'async function': '⌁ƒ',
    'async ': '⌁',
    'await ': '⌂',
    'import { ': '←{',
    ' } from ': '}←',
    'useState': '⟨S⟩',
    'useEffect': '⟨E⟩',
    'useCallback': '⟨C⟩',
    'useMemo': '⟨M⟩',
    'useRef': '⟨R⟩',
    'React.FC': 'ℜ',
    'Promise<': '℘<',
    'Array<': '⊂<',
    'Record<': '⊆<',
    'string': '§',
    'number': '№',
    'boolean': '⊤⊥',
    'undefined': '∅',
    'null': '⊘',
    'return ': '↩',
    'const ': '©',
    'let ': '⟠',
    'function ': 'ƒ',
    'interface ': '⌐',
    'type ': '⊤',
    'class ': '℃',
    'extends ': '⊃',
    'implements ': '⊇',
    'constructor': '⌂⌂',
    'this.': '⊙.',
    'console.log': '⊡',
    'console.error': '⊠',
    '=> {': '⟹{',
    '=> ': '⟹',
    '.map(': '.⊛(',
    '.filter(': '.⊜(',
    '.reduce(': '.⊝(',
    '.forEach(': '.⊞(',
    '.find(': '.⊟(',
    'try {': '⌑{',
    'catch (': '⌒(',
    'finally {': '⌓{',
    'throw new Error': '⌔⊠',
    'new Date()': '⌚',
    'Date.now()': '⌚⌚',
    'Math.': '∑.',
    'Object.': '⊙.',
    'Array.': '⊂.',
    'JSON.stringify': '⟦→§⟧',
    'JSON.parse': '⟦§→⟧',
    'process.env': '⊡⊛',
    '// ': '⌽',
    '/* ': '⌾',
    ' */': '⌿',
    '\n\n': '⏎⏎',
    '\n': '⏎',
    '  ': '→',
    '    ': '→→',
  };

  compress(code: string): { compressed: string; ratio: number } {
    let result = code;
    
    // Apply common pattern compression
    for (const [pattern, glyph] of Object.entries(this.COMMON_PATTERNS)) {
      result = result.split(pattern).join(glyph);
    }

    // Calculate compression ratio
    const originalTokens = this.estimateTokens(code);
    const compressedTokens = this.estimateTokens(result);
    const ratio = originalTokens > 0 ? (1 - compressedTokens / originalTokens) : 0;

    return { compressed: result, ratio };
  }

  decompress(glyph: string): string {
    let result = glyph;
    
    // Reverse the compression (order matters - reverse of compression order)
    const reversePairs = Object.entries(this.COMMON_PATTERNS).reverse();
    for (const [pattern, glyphChar] of reversePairs) {
      result = result.split(glyphChar).join(pattern);
    }

    return result;
  }

  estimateTokens(text: string): number {
    // Rough estimation: ~4 characters per token
    return Math.ceil(text.length / 4);
  }

  generateGlyph(content: string): string {
    const hash = crypto.createHash('md5').update(content).digest('hex').substring(0, 8);
    return `⟪${hash}⟫`;
  }
}

// ═══════════════════════════════════════════════════════════════
// PATTERN EXTRACTOR
// ═══════════════════════════════════════════════════════════════

class PatternExtractor {
  
  extractFromTypeScript(code: string, filePath: string): Partial<HarvestedPattern>[] {
    const patterns: Partial<HarvestedPattern>[] = [];
    const lines = code.split('\n');
    
    // Extract classes
    const classRegex = /(?:export\s+)?class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+(\w+))?/g;
    let match;
    while ((match = classRegex.exec(code)) !== null) {
      const lineNum = code.substring(0, match.index).split('\n').length;
      const classBody = this.extractBlock(code, match.index);
      patterns.push({
        type: 'class',
        name: match[1],
        code: classBody,
        triggers: this.extractTriggers(match[1], classBody),
        dependencies: this.extractDependencies(classBody),
        capabilities: this.extractCapabilities(classBody),
        metadata: {
          filePath,
          lineStart: lineNum,
          lineEnd: lineNum + classBody.split('\n').length,
          harvestedAt: new Date(),
          version: '1.0.0'
        }
      });
    }

    // Extract interfaces
    const interfaceRegex = /(?:export\s+)?interface\s+(\w+)(?:\s+extends\s+(\w+))?/g;
    while ((match = interfaceRegex.exec(code)) !== null) {
      const lineNum = code.substring(0, match.index).split('\n').length;
      const interfaceBody = this.extractBlock(code, match.index);
      patterns.push({
        type: 'interface',
        name: match[1],
        code: interfaceBody,
        triggers: this.extractTriggers(match[1], interfaceBody),
        dependencies: [],
        capabilities: this.extractCapabilities(interfaceBody),
        metadata: {
          filePath,
          lineStart: lineNum,
          lineEnd: lineNum + interfaceBody.split('\n').length,
          harvestedAt: new Date(),
          version: '1.0.0'
        }
      });
    }

    // Extract functions
    const functionRegex = /(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\([^)]*\)/g;
    while ((match = functionRegex.exec(code)) !== null) {
      const lineNum = code.substring(0, match.index).split('\n').length;
      const funcBody = this.extractBlock(code, match.index);
      patterns.push({
        type: 'function',
        name: match[1],
        code: funcBody,
        triggers: this.extractTriggers(match[1], funcBody),
        dependencies: this.extractDependencies(funcBody),
        capabilities: this.extractCapabilities(funcBody),
        metadata: {
          filePath,
          lineStart: lineNum,
          lineEnd: lineNum + funcBody.split('\n').length,
          harvestedAt: new Date(),
          version: '1.0.0'
        }
      });
    }

    // Extract React components
    const componentRegex = /(?:export\s+)?(?:const|function)\s+(\w+)(?::\s*React\.FC)?.*?=.*?\(/g;
    while ((match = componentRegex.exec(code)) !== null) {
      if (match[1][0] === match[1][0].toUpperCase()) { // Component names start with uppercase
        const lineNum = code.substring(0, match.index).split('\n').length;
        const compBody = this.extractBlock(code, match.index);
        if (compBody.includes('return') && (compBody.includes('<') || compBody.includes('React'))) {
          patterns.push({
            type: 'component',
            name: match[1],
            code: compBody,
            triggers: this.extractTriggers(match[1], compBody),
            dependencies: this.extractDependencies(compBody),
            capabilities: this.extractCapabilities(compBody),
            metadata: {
              filePath,
              lineStart: lineNum,
              lineEnd: lineNum + compBody.split('\n').length,
              harvestedAt: new Date(),
              version: '1.0.0'
            }
          });
        }
      }
    }

    // Extract hooks
    const hookRegex = /(?:export\s+)?(?:const|function)\s+(use\w+)/g;
    while ((match = hookRegex.exec(code)) !== null) {
      const lineNum = code.substring(0, match.index).split('\n').length;
      const hookBody = this.extractBlock(code, match.index);
      patterns.push({
        type: 'hook',
        name: match[1],
        code: hookBody,
        triggers: this.extractTriggers(match[1], hookBody),
        dependencies: this.extractDependencies(hookBody),
        capabilities: this.extractCapabilities(hookBody),
        metadata: {
          filePath,
          lineStart: lineNum,
          lineEnd: lineNum + hookBody.split('\n').length,
          harvestedAt: new Date(),
          version: '1.0.0'
        }
      });
    }

    return patterns;
  }

  private extractBlock(code: string, startIndex: number): string {
    let braceCount = 0;
    let started = false;
    let endIndex = startIndex;

    for (let i = startIndex; i < code.length; i++) {
      if (code[i] === '{') {
        braceCount++;
        started = true;
      } else if (code[i] === '}') {
        braceCount--;
      }

      if (started && braceCount === 0) {
        endIndex = i + 1;
        break;
      }
    }

    return code.substring(startIndex, endIndex);
  }

  private extractTriggers(name: string, code: string): string[] {
    const triggers: string[] = [];
    
    // Add name-based triggers
    const words = name.replace(/([A-Z])/g, ' $1').toLowerCase().trim().split(/\s+/);
    triggers.push(...words);

    // Add keyword-based triggers
    const keywords = [
      'analyze', 'data', 'route', 'agent', 'mesh', 'voice', 'security',
      'cost', 'optimize', 'memory', 'pattern', 'truth', 'verify', 'spawn',
      'build', 'create', 'factory', 'router', 'handler', 'service', 'api',
      'database', 'cache', 'compress', 'encrypt', 'validate', 'test'
    ];
    
    for (const keyword of keywords) {
      if (code.toLowerCase().includes(keyword)) {
        triggers.push(keyword);
      }
    }

    return [...new Set(triggers)];
  }

  private extractDependencies(code: string): string[] {
    const deps: string[] = [];
    const importRegex = /import\s+.*?from\s+['"]([^'"]+)['"]/g;
    let match;
    while ((match = importRegex.exec(code)) !== null) {
      deps.push(match[1]);
    }
    return deps;
  }

  private extractCapabilities(code: string): string[] {
    const caps: string[] = [];
    
    if (code.includes('async') || code.includes('await')) caps.push('async');
    if (code.includes('fetch') || code.includes('axios')) caps.push('http');
    if (code.includes('useState') || code.includes('useEffect')) caps.push('react-hooks');
    if (code.includes('encrypt') || code.includes('decrypt')) caps.push('encryption');
    if (code.includes('cache') || code.includes('memoize')) caps.push('caching');
    if (code.includes('route') || code.includes('router')) caps.push('routing');
    if (code.includes('spawn') || code.includes('factory')) caps.push('spawning');
    if (code.includes('voice') || code.includes('speech')) caps.push('voice');
    if (code.includes('cost') || code.includes('budget')) caps.push('cost-management');
    if (code.includes('verify') || code.includes('truth')) caps.push('verification');
    if (code.includes('compress') || code.includes('glyph')) caps.push('compression');
    if (code.includes('pattern') || code.includes('memory')) caps.push('pattern-storage');
    
    return caps;
  }

  inferDomain(pattern: Partial<HarvestedPattern>): string {
    const name = pattern.name?.toLowerCase() || '';
    const code = pattern.code?.toLowerCase() || '';
    
    if (name.includes('brain') || code.includes('brain')) return 'brain';
    if (name.includes('agent') || code.includes('agent')) return 'agents';
    if (name.includes('voice') || code.includes('voice')) return 'voice';
    if (name.includes('security') || code.includes('security')) return 'security';
    if (name.includes('cost') || code.includes('cost')) return 'cost-optimization';
    if (name.includes('memory') || code.includes('memory')) return 'memory';
    if (name.includes('truth') || code.includes('truth')) return 'truth-engine';
    if (name.includes('router') || code.includes('router')) return 'routing';
    if (name.includes('factory') || code.includes('factory')) return 'factory';
    if (name.includes('compress') || code.includes('glyph')) return 'compression';
    if (pattern.type === 'component') return 'ui';
    if (pattern.type === 'hook') return 'hooks';
    
    return 'general';
  }
}

// ═══════════════════════════════════════════════════════════════
// GRIMOIRE (Pattern Storage)
// ═══════════════════════════════════════════════════════════════

class Grimoire {
  private entries: Map<string, GrimoireEntry> = new Map();
  private domainIndex: Map<string, string[]> = new Map();
  private triggerIndex: Map<string, string[]> = new Map();
  private capabilityIndex: Map<string, string[]> = new Map();

  store(pattern: HarvestedPattern): void {
    const glyph = pattern.compressed.substring(0, 100); // Use first 100 chars as glyph key
    
    if (!this.entries.has(glyph)) {
      this.entries.set(glyph, {
        glyph,
        patterns: [],
        accessCount: 0,
        lastAccessed: new Date(),
        successRate: 1.0,
        manifestations: 0
      });
    }

    const entry = this.entries.get(glyph)!;
    entry.patterns.push(pattern);

    // Update indexes
    this.updateIndex(this.domainIndex, pattern.domain, pattern.id);
    pattern.triggers.forEach(t => this.updateIndex(this.triggerIndex, t, pattern.id));
    pattern.capabilities.forEach(c => this.updateIndex(this.capabilityIndex, c, pattern.id));
  }

  private updateIndex(index: Map<string, string[]>, key: string, patternId: string): void {
    if (!index.has(key)) {
      index.set(key, []);
    }
    index.get(key)!.push(patternId);
  }

  query(params: {
    domain?: string;
    triggers?: string[];
    capabilities?: string[];
    limit?: number;
  }): HarvestedPattern[] {
    const candidates = new Set<string>();
    
    if (params.domain) {
      const domainPatterns = this.domainIndex.get(params.domain) || [];
      domainPatterns.forEach(id => candidates.add(id));
    }

    if (params.triggers) {
      for (const trigger of params.triggers) {
        const triggerPatterns = this.triggerIndex.get(trigger) || [];
        triggerPatterns.forEach(id => candidates.add(id));
      }
    }

    if (params.capabilities) {
      for (const cap of params.capabilities) {
        const capPatterns = this.capabilityIndex.get(cap) || [];
        capPatterns.forEach(id => candidates.add(id));
      }
    }

    // If no filters, return all
    if (candidates.size === 0 && !params.domain && !params.triggers && !params.capabilities) {
      const allPatterns: HarvestedPattern[] = [];
      this.entries.forEach(entry => allPatterns.push(...entry.patterns));
      return allPatterns.slice(0, params.limit || 100);
    }

    // Find patterns by ID
    const results: HarvestedPattern[] = [];
    this.entries.forEach(entry => {
      for (const pattern of entry.patterns) {
        if (candidates.has(pattern.id)) {
          results.push(pattern);
          entry.accessCount++;
          entry.lastAccessed = new Date();
        }
      }
    });

    return results.slice(0, params.limit || 100);
  }

  manifest(prompt: string): HarvestedPattern[] {
    // Extract keywords from prompt
    const words = prompt.toLowerCase().split(/\s+/);
    
    // Find matching patterns
    const matches = this.query({
      triggers: words,
      limit: 10
    });

    // Record manifestation
    matches.forEach(pattern => {
      const entry = Array.from(this.entries.values())
        .find(e => e.patterns.some(p => p.id === pattern.id));
      if (entry) {
        entry.manifestations++;
      }
    });

    return matches;
  }

  getStats(): {
    totalPatterns: number;
    totalGlyphs: number;
    domains: string[];
    triggers: string[];
    capabilities: string[];
    topAccessed: Array<{ glyph: string; count: number }>;
  } {
    const topAccessed = Array.from(this.entries.values())
      .sort((a, b) => b.accessCount - a.accessCount)
      .slice(0, 10)
      .map(e => ({ glyph: e.glyph.substring(0, 20), count: e.accessCount }));

    let totalPatterns = 0;
    this.entries.forEach(e => totalPatterns += e.patterns.length);

    return {
      totalPatterns,
      totalGlyphs: this.entries.size,
      domains: Array.from(this.domainIndex.keys()),
      triggers: Array.from(this.triggerIndex.keys()),
      capabilities: Array.from(this.capabilityIndex.keys()),
      topAccessed
    };
  }

  export(): string {
    const data = {
      entries: Array.from(this.entries.entries()),
      domainIndex: Array.from(this.domainIndex.entries()),
      triggerIndex: Array.from(this.triggerIndex.entries()),
      capabilityIndex: Array.from(this.capabilityIndex.entries())
    };
    return JSON.stringify(data, null, 2);
  }
}

// ═══════════════════════════════════════════════════════════════
// UNIFIED HARVESTER
// ═══════════════════════════════════════════════════════════════

export class UnifiedHarvester {
  private glyphEngine: GlyphEngine;
  private patternExtractor: PatternExtractor;
  private grimoire: Grimoire;
  private stats: HarvesterStats;

  constructor() {
    this.glyphEngine = new GlyphEngine();
    this.patternExtractor = new PatternExtractor();
    this.grimoire = new Grimoire();
    this.stats = {
      filesProcessed: 0,
      patternsExtracted: 0,
      totalLines: 0,
      totalTokens: 0,
      compressedTokens: 0,
      avgCompressionRatio: 0,
      domains: {},
      types: {}
    };
  }

  async harvestDirectory(dirPath: string): Promise<void> {
    console.log(`\n⚡ HARVESTING: ${dirPath}`);
    console.log('═'.repeat(60));

    const files = this.walkDirectory(dirPath);
    
    for (const file of files) {
      if (this.isCodeFile(file)) {
        await this.harvestFile(file);
      }
    }

    console.log('\n✅ HARVEST COMPLETE');
    this.printStats();
  }

  private walkDirectory(dir: string): string[] {
    const files: string[] = [];
    
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        
        // Skip node_modules, .git, etc.
        if (entry.name.startsWith('.') || entry.name === 'node_modules') {
          continue;
        }

        if (entry.isDirectory()) {
          files.push(...this.walkDirectory(fullPath));
        } else {
          files.push(fullPath);
        }
      }
    } catch (err) {
      console.warn(`⚠️ Could not read directory: ${dir}`);
    }

    return files;
  }

  private isCodeFile(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    return ['.ts', '.tsx', '.js', '.jsx', '.py'].includes(ext);
  }

  async harvestFile(filePath: string): Promise<void> {
    try {
      const code = fs.readFileSync(filePath, 'utf-8');
      const lines = code.split('\n').length;
      
      this.stats.filesProcessed++;
      this.stats.totalLines += lines;

      // Extract patterns
      const patterns = this.patternExtractor.extractFromTypeScript(code, filePath);
      
      for (const partial of patterns) {
        // Complete the pattern
        const pattern: HarvestedPattern = {
          id: crypto.randomUUID(),
          type: partial.type!,
          name: partial.name!,
          domain: this.patternExtractor.inferDomain(partial),
          source: filePath,
          code: partial.code!,
          compressed: '',
          tokens: 0,
          compressedTokens: 0,
          compressionRatio: 0,
          triggers: partial.triggers!,
          dependencies: partial.dependencies!,
          capabilities: partial.capabilities!,
          metadata: partial.metadata!
        };

        // Compress
        const { compressed, ratio } = this.glyphEngine.compress(pattern.code);
        pattern.compressed = compressed;
        pattern.tokens = this.glyphEngine.estimateTokens(pattern.code);
        pattern.compressedTokens = this.glyphEngine.estimateTokens(compressed);
        pattern.compressionRatio = ratio;

        // Store in grimoire
        this.grimoire.store(pattern);

        // Update stats
        this.stats.patternsExtracted++;
        this.stats.totalTokens += pattern.tokens;
        this.stats.compressedTokens += pattern.compressedTokens;
        this.stats.domains[pattern.domain] = (this.stats.domains[pattern.domain] || 0) + 1;
        this.stats.types[pattern.type] = (this.stats.types[pattern.type] || 0) + 1;

        console.log(`  📦 ${pattern.type.toUpperCase()}: ${pattern.name} [${pattern.domain}] (${(ratio * 100).toFixed(1)}% compressed)`);
      }

    } catch (err) {
      console.warn(`⚠️ Could not process: ${filePath}`);
    }
  }

  private printStats(): void {
    this.stats.avgCompressionRatio = this.stats.totalTokens > 0 
      ? (1 - this.stats.compressedTokens / this.stats.totalTokens) 
      : 0;

    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('📊 HARVEST STATISTICS');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log(`   Files Processed:     ${this.stats.filesProcessed}`);
    console.log(`   Patterns Extracted:  ${this.stats.patternsExtracted}`);
    console.log(`   Total Lines:         ${this.stats.totalLines.toLocaleString()}`);
    console.log(`   Total Tokens:        ${this.stats.totalTokens.toLocaleString()}`);
    console.log(`   Compressed Tokens:   ${this.stats.compressedTokens.toLocaleString()}`);
    console.log(`   Avg Compression:     ${(this.stats.avgCompressionRatio * 100).toFixed(1)}%`);
    console.log('');
    console.log('   DOMAINS:');
    Object.entries(this.stats.domains)
      .sort((a, b) => b[1] - a[1])
      .forEach(([domain, count]) => {
        console.log(`     ${domain}: ${count}`);
      });
    console.log('');
    console.log('   TYPES:');
    Object.entries(this.stats.types)
      .sort((a, b) => b[1] - a[1])
      .forEach(([type, count]) => {
        console.log(`     ${type}: ${count}`);
      });
    console.log('═══════════════════════════════════════════════════════════════');
  }

  // MANIFESTATION - Turn a prompt into code
  manifest(prompt: string): { patterns: HarvestedPattern[]; code: string } {
    console.log(`\n🔮 MANIFESTING: "${prompt}"`);
    
    const patterns = this.grimoire.manifest(prompt);
    
    if (patterns.length === 0) {
      console.log('   No matching patterns found.');
      return { patterns: [], code: '' };
    }

    console.log(`   Found ${patterns.length} matching patterns:`);
    patterns.forEach(p => {
      console.log(`   - ${p.name} [${p.domain}] (${p.capabilities.join(', ')})`);
    });

    // Decompress and combine
    const decompressedCode = patterns
      .map(p => this.glyphEngine.decompress(p.compressed))
      .join('\n\n// ═══════════════════════════════════════\n\n');

    return { patterns, code: decompressedCode };
  }

  getGrimoire(): Grimoire {
    return this.grimoire;
  }

  getStats(): HarvesterStats {
    return this.stats;
  }

  exportGrimoire(): string {
    return this.grimoire.export();
  }
}

// ═══════════════════════════════════════════════════════════════
// MAIN EXECUTION
// ═══════════════════════════════════════════════════════════════

async function main() {
  console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║     ██████  ██████  ██████      ██   ██  █████  ██████        ║
║    ██  ████ ██   ██ ██   ██     ██   ██ ██   ██ ██   ██       ║
║    ██ ██ ██ ██████  ██████      ███████ ███████ ██████        ║
║    ████  ██ ██   ██ ██   ██     ██   ██ ██   ██ ██   ██       ║
║     ██████  ██   ██ ██████      ██   ██ ██   ██ ██   ██       ║
║                                                               ║
║            UNIFIED HARVESTER v1.0                             ║
║         "The Pattern Reader That Builds The Builder"          ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
  `);

  const harvester = new UnifiedHarvester();

  // Harvest all directories
  const directories = [
    './amoebasec-orbos',
    './project-sundae',
    './voice-agency',
    './drive-export'
  ];

  for (const dir of directories) {
    if (fs.existsSync(dir)) {
      await harvester.harvestDirectory(dir);
    }
  }

  // Print grimoire stats
  const grimoireStats = harvester.getGrimoire().getStats();
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('📚 GRIMOIRE STATUS');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`   Total Patterns: ${grimoireStats.totalPatterns}`);
  console.log(`   Total Glyphs: ${grimoireStats.totalGlyphs}`);
  console.log(`   Domains: ${grimoireStats.domains.join(', ')}`);
  console.log(`   Capabilities: ${grimoireStats.capabilities.slice(0, 10).join(', ')}`);
  console.log('═══════════════════════════════════════════════════════════════');

  // Test manifestation
  console.log('\n🧪 TESTING MANIFESTATION...');
  const testPrompts = [
    'create an agent factory',
    'route ai requests to cheapest provider',
    'compress code into glyphs',
    'spawn security auditor'
  ];

  for (const prompt of testPrompts) {
    const result = harvester.manifest(prompt);
    console.log(`   "${prompt}" → ${result.patterns.length} patterns`);
  }

  // Export grimoire
  const grimoireExport = harvester.exportGrimoire();
  fs.writeFileSync('./grimoire-export.json', grimoireExport);
  console.log('\n💾 Grimoire exported to: ./grimoire-export.json');

  console.log('\n✨ HARVESTER COMPLETE - THE BUILDER IS BUILT');
}

// Export for use as module
export { GlyphEngine, PatternExtractor, Grimoire };

// Run if executed directly
if (require.main === module) {
  main().catch(console.error);
}
