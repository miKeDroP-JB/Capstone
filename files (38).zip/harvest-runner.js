/**
 * 0RB UNIFIED HARVESTER - Node.js Runner
 * Processes all extracted code and builds the pattern library
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ═══════════════════════════════════════════════════════════════
// GLYPH COMPRESSION
// ═══════════════════════════════════════════════════════════════

const COMMON_PATTERNS = {
  'export default function': '⊕ƒ',
  'export const': '⊕©',
  'export interface': '⊕⌐',
  'export class': '⊕℃',
  'async function': '⌁ƒ',
  'async ': '⌁',
  'await ': '⌂',
  'useState': '⟨S⟩',
  'useEffect': '⟨E⟩',
  'React.FC': 'ℜ',
  'Promise<': '℘<',
  'return ': '↩',
  'const ': '©',
  'function ': 'ƒ',
  'interface ': '⌐',
  'class ': '℃',
  '=> {': '⟹{',
  '=> ': '⟹',
  '.map(': '.⊛(',
  '.filter(': '.⊜(',
  '\n': '⏎',
};

function compress(code) {
  let result = code;
  for (const [pattern, glyph] of Object.entries(COMMON_PATTERNS)) {
    result = result.split(pattern).join(glyph);
  }
  const originalTokens = Math.ceil(code.length / 4);
  const compressedTokens = Math.ceil(result.length / 4);
  const ratio = originalTokens > 0 ? (1 - compressedTokens / originalTokens) : 0;
  return { compressed: result, ratio, originalTokens, compressedTokens };
}

// ═══════════════════════════════════════════════════════════════
// PATTERN EXTRACTION
// ═══════════════════════════════════════════════════════════════

function extractPatterns(code, filePath) {
  const patterns = [];
  
  // Extract classes
  const classRegex = /(?:export\s+)?class\s+(\w+)/g;
  let match;
  while ((match = classRegex.exec(code)) !== null) {
    patterns.push({
      type: 'class',
      name: match[1],
      domain: inferDomain(match[1], code),
      source: filePath
    });
  }

  // Extract interfaces
  const interfaceRegex = /(?:export\s+)?interface\s+(\w+)/g;
  while ((match = interfaceRegex.exec(code)) !== null) {
    patterns.push({
      type: 'interface',
      name: match[1],
      domain: inferDomain(match[1], code),
      source: filePath
    });
  }

  // Extract functions
  const functionRegex = /(?:export\s+)?(?:async\s+)?function\s+(\w+)/g;
  while ((match = functionRegex.exec(code)) !== null) {
    patterns.push({
      type: 'function',
      name: match[1],
      domain: inferDomain(match[1], code),
      source: filePath
    });
  }

  // Extract React components (PascalCase const/function)
  const componentRegex = /(?:export\s+)?(?:const|function)\s+([A-Z]\w+)/g;
  while ((match = componentRegex.exec(code)) !== null) {
    if (code.includes('return') && (code.includes('<') || code.includes('React'))) {
      patterns.push({
        type: 'component',
        name: match[1],
        domain: 'ui',
        source: filePath
      });
    }
  }

  return patterns;
}

function inferDomain(name, code) {
  const n = name.toLowerCase();
  const c = code.toLowerCase();
  if (n.includes('brain') || c.includes('brain')) return 'brain';
  if (n.includes('agent') || c.includes('agent')) return 'agents';
  if (n.includes('voice') || c.includes('voice')) return 'voice';
  if (n.includes('security') || c.includes('security')) return 'security';
  if (n.includes('cost') || c.includes('cost')) return 'cost-optimization';
  if (n.includes('memory') || c.includes('memory')) return 'memory';
  if (n.includes('truth') || c.includes('truth')) return 'truth-engine';
  if (n.includes('router') || c.includes('router')) return 'routing';
  if (n.includes('factory') || c.includes('factory')) return 'factory';
  if (n.includes('compress') || c.includes('glyph')) return 'compression';
  if (n.includes('intent') || c.includes('intent')) return 'intent';
  if (n.includes('forge') || c.includes('forge')) return 'forge';
  return 'general';
}

// ═══════════════════════════════════════════════════════════════
// FILE WALKING
// ═══════════════════════════════════════════════════════════════

function walkDirectory(dir) {
  const files = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
      if (entry.isDirectory()) {
        files.push(...walkDirectory(fullPath));
      } else if (['.ts', '.tsx', '.js', '.jsx', '.py'].includes(path.extname(entry.name))) {
        files.push(fullPath);
      }
    }
  } catch (err) { }
  return files;
}

// ═══════════════════════════════════════════════════════════════
// MAIN HARVEST
// ═══════════════════════════════════════════════════════════════

console.log(`
╔═══════════════════════════════════════════════════════════════╗
║     ██████  ██████  ██████      ██   ██  █████  ██████        ║
║    ██  ████ ██   ██ ██   ██     ██   ██ ██   ██ ██   ██       ║
║    ██ ██ ██ ██████  ██████      ███████ ███████ ██████        ║
║    ████  ██ ██   ██ ██   ██     ██   ██ ██   ██ ██   ██       ║
║     ██████  ██   ██ ██████      ██   ██ ██   ██ ██   ██       ║
║                                                               ║
║            UNIFIED HARVESTER v1.0                             ║
║         "The Pattern Reader That Builds The Builder"          ║
╚═══════════════════════════════════════════════════════════════╝
`);

const stats = {
  filesProcessed: 0,
  patternsExtracted: 0,
  totalLines: 0,
  totalTokens: 0,
  compressedTokens: 0,
  domains: {},
  types: {}
};

const grimoire = [];

const directories = [
  './amoebasec-orbos',
  './project-sundae',
  './voice-agency',
  './drive-export'
];

for (const dir of directories) {
  if (!fs.existsSync(dir)) continue;
  console.log(`\n⚡ HARVESTING: ${dir}`);
  console.log('═'.repeat(60));

  const files = walkDirectory(dir);
  
  for (const file of files) {
    try {
      const code = fs.readFileSync(file, 'utf-8');
      const lines = code.split('\n').length;
      stats.filesProcessed++;
      stats.totalLines += lines;

      const { compressed, ratio, originalTokens, compressedTokens } = compress(code);
      stats.totalTokens += originalTokens;
      stats.compressedTokens += compressedTokens;

      const patterns = extractPatterns(code, file);
      
      for (const pattern of patterns) {
        stats.patternsExtracted++;
        stats.domains[pattern.domain] = (stats.domains[pattern.domain] || 0) + 1;
        stats.types[pattern.type] = (stats.types[pattern.type] || 0) + 1;
        
        grimoire.push({
          ...pattern,
          id: crypto.randomUUID(),
          compression: (ratio * 100).toFixed(1) + '%'
        });

        console.log(`  📦 ${pattern.type.toUpperCase().padEnd(10)} ${pattern.name.padEnd(30)} [${pattern.domain}]`);
      }
    } catch (err) { }
  }
}

// Print stats
console.log(`
═══════════════════════════════════════════════════════════════
📊 HARVEST STATISTICS
═══════════════════════════════════════════════════════════════
   Files Processed:     ${stats.filesProcessed}
   Patterns Extracted:  ${stats.patternsExtracted}
   Total Lines:         ${stats.totalLines.toLocaleString()}
   Total Tokens:        ${stats.totalTokens.toLocaleString()}
   Compressed Tokens:   ${stats.compressedTokens.toLocaleString()}
   Avg Compression:     ${((1 - stats.compressedTokens/stats.totalTokens) * 100).toFixed(1)}%

   DOMAINS:
${Object.entries(stats.domains).sort((a,b) => b[1]-a[1]).map(([d,c]) => `     ${d.padEnd(20)} ${c}`).join('\n')}

   TYPES:
${Object.entries(stats.types).sort((a,b) => b[1]-a[1]).map(([t,c]) => `     ${t.padEnd(20)} ${c}`).join('\n')}
═══════════════════════════════════════════════════════════════
`);

// Export grimoire
fs.writeFileSync('./grimoire.json', JSON.stringify({ patterns: grimoire, stats }, null, 2));
console.log('💾 Grimoire exported to: ./grimoire.json');
console.log('\n✨ HARVESTER COMPLETE - THE BUILDER IS BUILT');
